<?php include 'header.html';?>
<?php include 'home.html';?>
<?php include 'footer.html';?>